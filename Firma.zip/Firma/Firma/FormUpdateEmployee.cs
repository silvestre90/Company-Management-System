﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Firma
{
    public partial class FormUpdateEmployee : Form
    {
        public FormUpdateEmployee()
        {
            InitializeComponent();
        }

        public FormUpdateEmployee(BasicEmployee employee)
        {
            InitializeComponent();
            this.label1.Text = $"Update {employee.Name} and {employee.Surname}";
            FieldsInteractionManager.fillComboboxWithValues(Department.getDepartments(), cmbDepartment);
            cmbDepartment.Text = employee.Department;

            cmbPosition.DataSource = Enum.GetValues(typeof(Position));
            cmbPosition.Text = employee.EmployeePosition;
        }
    }
}
