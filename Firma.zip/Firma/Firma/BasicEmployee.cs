﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma
{

    public class BasicEmployee
    {
        public int EmployeeID { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string EmployeePosition { get; set; }
        public string Department { get; set; }
        public int AddressID { get; set; }
        public int EmployeeDataID { get; set; }

        public BasicEmployee(int employeeID, string name, string surname, string employeePosition, string department, int addressID, int empDataId)
        {
            EmployeeID = employeeID;
            Name = name;
            Surname = surname;
            EmployeePosition = employeePosition;
            Department = department;
            AddressID = addressID;
            EmployeeDataID = empDataId;
        }
    }
}
