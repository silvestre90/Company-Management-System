﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Firma
{
    static class FieldsInteractionManager
    {
        public static Color Creamy = Color.FromArgb(255, 255, 253);
        public static Color CorrectColor = Color.White;

        public static void setCreamyColor(Control control)
        {
            control.BackColor = Creamy;
        }
        public static void setCorrectColor(Control control)
        {
            control.BackColor = CorrectColor;
        }

        public static void setNeutralColor(Control control)
        {
            control.BackColor = Color.LightGray;
        }

        public static void setErrorColor(Control control)
        {
            control.BackColor = Color.Red;
        }

        public static void performDefaultValidation(Control control)
        {
            setCorrectColor(control);

            if (control.Text.Length == 0)
            {
                setNeutralColor(control);
            }
        }

        public static void fillComboboxWithValues(List<String> cmbItems, ComboBox comboBox)
        {
            comboBox.Items.Clear();

            foreach (var item in cmbItems)
            {
                 comboBox.Items.Add(item);
            }
        }
    }
}
