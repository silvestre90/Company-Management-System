﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Firma.CRUD;

namespace Firma.ExtendedFunctionalities
{
    class Promotor
    {

        public Employee PromoteRandomEmployee()
        {
            IGetable DataMan = new DisplayDataManager();
            List<Employee> allEmployees = DataMan.GetAllEmployees();
            int listSize = allEmployees.Count();

            Random rnd = new Random();
            Employee empToBePromoted = new Employee();
            do
            {
                int employeeIndex = rnd.Next(1, listSize);
                int counter = 1;
                
                foreach (Employee emp in allEmployees)
                {
                    if(counter == employeeIndex)
                    {
                        empToBePromoted = emp;
                        break;
                    }
                    counter++;
                }
            } while(empToBePromoted.EmployeeData.EmployeePosition == Position.director.ToString());

            UpdateEmployeePosition(empToBePromoted);
            return DataMan.GetEmployeeById(empToBePromoted.EmployeeID);
        }

        private void UpdateEmployeePosition(Employee empToBePromoted)
        {
            IUpdatable updateManager = new UpdateDataManager();
            updateManager.PromoteEmployee(empToBePromoted, PositionOneLevelAbove(
                                          empToBePromoted.EmployeeData.EmployeePosition));
        }

        private string PositionOneLevelAbove(string employeePosition)
        {
            int positionIndex = GetCurrentPositionIndex(employeePosition);

            return ((Position)positionIndex + 1).ToString();
        }

        private int GetCurrentPositionIndex(string employeePosition)
        {
            int numberOfPositions = Enum.GetNames(typeof(Position)).Length;
            for (int i = 1; i < numberOfPositions; i++)
            {
                if (employeePosition == ((Position)i).ToString())
                {
                    return i;
                }
            }
            return 0;
        }
    }
}
