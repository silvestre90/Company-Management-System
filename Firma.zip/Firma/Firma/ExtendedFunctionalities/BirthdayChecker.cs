﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Firma.CRUD;

namespace Firma.ExtendedFunctionalities
{
    class BirthdayChecker
    {
        public CRUD.IGetable DataManager { get; set; }

        public List<Employee> BirthdayEmployees()
        {
            List<Employee> allEmployees = DataManager.GetAllEmployees();
            List<Employee> birthdays = new List<Employee>();

            foreach (Employee emp in allEmployees)
            {
                if (HasBirthday(emp))
                {
                    birthdays.Add(emp);
                }
            }

            return birthdays;
        }
        public BirthdayChecker()
        {
            DataManager = new DisplayDataManager();
        }

        public bool HasBirthday(Employee emp)
        {
            DateTime today = DateTime.Now;
            if (MonthMatches(today, emp.BirthDate) && DayMatches(today, emp.BirthDate))
            {
                return true;
            }
            return false;

        }

        private bool DayMatches(DateTime today, DateTime birthDate)
        {
            
            int dayOfMonthNow = DateTime.DaysInMonth(today.Year, today.Month);
            int dayOfMonthEmployee = DateTime.DaysInMonth(birthDate.Year, birthDate.Month);

            return (today.Day == birthDate.Day);
        }

        private bool MonthMatches(DateTime actualDate, DateTime employeeBirthDate)
        {
            return (actualDate.ToString("MMM") == employeeBirthDate.ToString("MMM"));
        }

        internal string generateBirthdayMessage(List<Employee> birthdayEmps)
        {
            if(birthdayEmps.Count == 0)
            {
                return "Nobody has birthday today";
            }
            else
            {
                string message = "Today is the birthday of:";
                foreach (Employee emp in birthdayEmps)
                {
                    message += $"\n {emp.ToString()}";
                }
                return message;
            }
            
        }
    }
}


    

