﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Firma
{
    public partial class FormMain : Form
    {

        Department dep = new Department();
        private const string addDep = "Add Department";
        private const string confirmDep = "Confirm";
        public const string RemovalMode = "Remove Employee";
        public const string EditMode = "Edit Employee";


        public FormMain()
        {
            InitializeComponent();
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbPositions.DataSource = Enum.GetValues(typeof(Position));
            cmbDate.Value = FieldsValidator.FirstDate;
            cmbEmploymentDate.Value = FieldsValidator.FirstDate; 
            updateDepartments();
        }

        private void updateDepartments()
        {
            FieldsInteractionManager.fillComboboxWithValues(dep.departments, cmbDepartment);
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private List<Control> initializeTextBoxesList()
        {
            List<Control> textBoxesList = new List<Control>();
            textBoxesList.Add(textBoxName);
            textBoxesList.Add(textBoxSurname);
            textBoxesList.Add(textBoxCity);
            textBoxesList.Add(textBoxStreet);
            textBoxesList.Add(maskedTextBoxZip);
            textBoxesList.Add(textBoxSalary);

            return textBoxesList;
        }

        private List<DateTimePicker> initializeDates()
        {
            List<DateTimePicker> datesList = new List<DateTimePicker>();
            datesList.Add(cmbDate);
            datesList.Add(cmbEmploymentDate);

            return datesList;
        }
        private void btnSaveEmployee_Click(object sender, EventArgs e)
        {   //todo - pola maja sie czyscic po pomyslnym zapisaniu
            List<Control> textBoxesList = initializeTextBoxesList();
            List<DateTimePicker> datesList = initializeDates();
            if (cmbPositions.SelectedValue.Equals(Position.director))
            {
                textBoxesList.Add(maskedTextBoxRoom);

                if (FieldsValidator.isEmployeeDataValid(textBoxesList, datesList))
                {
                    Employee employee = getEmployee();
                    Director director = new Director(Convert.ToInt32(maskedTextBoxRoom.Text.ToString()),
                                        employee);
                    AddDataManager DataManager = new AddDataManager();
                    DataManager.addNewDirector(director);
                }
                else
                {
                    FieldsValidator.showErrorMessage(cmbPositions.SelectedValue.ToString());
                } 
            }
            else if (cmbPositions.SelectedValue.Equals(Position.asistant))
            {
                textBoxesList.Add(textBoxPhoneNumber);
                if (FieldsValidator.isEmployeeDataValid(textBoxesList, datesList))
                {
                    Employee employee = getEmployee();
                    Asistant asistant = new Asistant(textBoxPhoneNumber.Text, employee);
                    AddDataManager DataManager = new AddDataManager();
                    DataManager.addNewAsistant(asistant);
                }
                else
                {
                    FieldsValidator.showErrorMessage(cmbPositions.SelectedValue.ToString());
                }
            }
            else
            {
                if (FieldsValidator.isEmployeeDataValid(textBoxesList, datesList))
                {
                    Employee employee = getEmployee();
                    AddDataManager DataManager = new AddDataManager();
                    DataManager.addNewEmployee(employee);
                }
                else
                {
                    FieldsValidator.showErrorMessage(cmbPositions.SelectedValue.ToString());
                }
            }
        }

        private Employee getEmployee()
        {
            Address address = getAddress();
            EmployeeData employeeData = getEmployeeData();
            Employee emp;
            if (cmbPositions.Text == Position.director.ToString() ||
                cmbPositions.Text == Position.asistant.ToString())
            {
                emp = new Employee(textBoxName.Text.ToString(), textBoxSurname.Text.ToString(),
                                        cmbDate.Value, employeeData, address);
            }
            else
            {
                emp = new Employee(textBoxName.Text, textBoxSurname.Text, cmbDate.Value, cmbPositions.Text,
                                   employeeData, address);
            }
            return emp;
        }

        private EmployeeData getEmployeeData()
        {
            EmployeeData ed =  new EmployeeData(cmbDepartment.Text,
                                                cmbEmploymentDate.Value,
                                                Convert.ToDouble(textBoxSalary.Text));
            return ed;
        }

        private Address getAddress()
        {
            Address ad =new Address(textBoxCity.Text.ToString(),
                                    textBoxStreet.Text.ToString(),
                                    maskedTextBoxZip.Text.ToString());
            return ad;
        }

        private void btnAddDepartment_Click(object sender, EventArgs e)
        {
            if (btnAddDepartment.Text == addDep)
            {
                txtNewDep.ReadOnly = false;
                switchBtnNames(true);
            }
            else
            {
                switchBtnNames(false);
                string departmentName = txtNewDep.Text;
                txtNewDep.Text = "";
                txtNewDep.ReadOnly = true;

                if (departmentName != "")
                {
                    dep.returnUpdatedList(departmentName);
                    updateDepartments();
                    MessageBox.Show("New department added");
                }
                else
                {
                    MessageBox.Show("New department cannot be empty");
                }

            }
        }

        private void switchBtnNames(bool shouldSwitch)
        {
            if (shouldSwitch)
            {
                btnAddDepartment.Text = confirmDep;
            }
            else
            {
                btnAddDepartment.Text = addDep;
            }
        }

        private void cmbDate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void cmbPositions_SelectedIndexChanged(object sender, EventArgs e)
        {

            textBoxPhoneNumber.ReadOnly = true;
            maskedTextBoxRoom.ReadOnly = true;

            if (cmbPositions.Text == Position.director.ToString())
            {
                maskedTextBoxRoom.Text = "";
                textBoxPhoneNumber.Text = "";
                FieldsInteractionManager.setCreamyColor(maskedTextBoxRoom);
                FieldsInteractionManager.setNeutralColor(textBoxPhoneNumber);
                maskedTextBoxRoom.ReadOnly = false;
            }
            else if (cmbPositions.Text == Position.asistant.ToString())
            {
                maskedTextBoxRoom.Text = "";
                textBoxPhoneNumber.Text = "";
                FieldsInteractionManager.setNeutralColor(maskedTextBoxRoom);
                FieldsInteractionManager.setCreamyColor(textBoxPhoneNumber);
                textBoxPhoneNumber.ReadOnly = false;
            }
            else
            {
                maskedTextBoxRoom.Text = "";
                textBoxPhoneNumber.Text = "";
            }
            
            FieldsInteractionManager.setCorrectColor(this.cmbPositions);
        }


        private void maskedTextBoxZip_TextChanged(object sender, EventArgs e)
        {
            FieldsInteractionManager.setCorrectColor(maskedTextBoxZip);

            if (maskedTextBoxZip.Text != "  -")
            {

                if (!FieldsValidator.valueMatchesRegex(@"^(\d{2}-\d{3})$", maskedTextBoxZip.Text))
                {
                    FieldsInteractionManager.setErrorColor(maskedTextBoxZip);
                }
            }
            else
            {
                FieldsInteractionManager.setNeutralColor(this);
            }

        }


        private void textBoxSalary_TextChanged(object sender, EventArgs e)
        {
            textBoxSalary.BackColor = Color.White;

            if (textBoxSalary.Text.Length > 0)
            {

                if (!FieldsValidator.valueMatchesRegex(@"^[1-9]{1}[0-9]{4,6}$", textBoxSalary.Text))
                {
                    textBoxSalary.BackColor = Color.Red;
                }
            }
            else
            {
                textBoxSalary.BackColor = Color.LightGray;
            }

        }

        private void textBoxPhoneNumber_TextChanged(object sender, EventArgs e)
        {
            textBoxPhoneNumber.BackColor = Color.White;

            if (textBoxPhoneNumber.Text.Length > 0)
            {

                if (!FieldsValidator.valueMatchesRegex(@"^[1-9]{1}(\d){8}$", textBoxPhoneNumber.Text))
                {
                    textBoxPhoneNumber.BackColor = Color.Red;
                }
            }
            else
            {
                textBoxPhoneNumber.BackColor = Color.LightGray;
            }

        }

        private void maskedTextBoxRoom_TextChanged(object sender, EventArgs e)
        {
            FieldsInteractionManager.performDefaultValidation(this.maskedTextBoxRoom);
        }

        private void textBoxName_TextChanged(object sender, EventArgs e)
        {
            FieldsInteractionManager.performDefaultValidation(this.textBoxName);
        }

        private void textBoxSurname_TextChanged(object sender, EventArgs e)
        {
            FieldsInteractionManager.performDefaultValidation(this.textBoxSurname);
        }

        private void textBoxCity_TextChanged(object sender, EventArgs e)
        {
            FieldsInteractionManager.performDefaultValidation(this.textBoxCity);
        }

        private void textBoxStreet_TextChanged(object sender, EventArgs e)
        {
            FieldsInteractionManager.performDefaultValidation(this.textBoxStreet);
        }

        private void cmbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            FieldsInteractionManager.setCorrectColor(cmbDepartment);
        }

        private void btnShowData_Click(object sender, EventArgs e)
        {
            FormChooseParameterToFilter f2 = new FormChooseParameterToFilter();
            f2.Show();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            FormFilterEmployee form = new FormFilterEmployee(EditMode);
            form.Show();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            FormFilterEmployee form = new FormFilterEmployee(RemovalMode);
            form.Show();
        }
    }
}
