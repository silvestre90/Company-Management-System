﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma
{
    interface IDataInteraction
    {
        //todo - pytanie, dlaczego interfejsy nie moga zawierac pol?
        List<string> getDepartments();
        void addNewDepartment(string departmentName);
    
    }
}
