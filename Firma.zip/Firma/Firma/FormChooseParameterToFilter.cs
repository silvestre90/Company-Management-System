﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Firma
{
    public partial class FormChooseParameterToFilter : Form
    {
        DisplayDataManager DataMan;
        public FormChooseParameterToFilter()
        {
            DataMan = new DisplayDataManager();
            InitializeComponent();
        }

        private void FormChooseParameterToFilter_Load(object sender, EventArgs e)
        {

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            FormShowEmployees form;
            if (radioButtonAll.Checked)
            {
                List<BasicEmployee> allEmployees = DataMan.getAllBasicEmployeeInfoToList();
                form = new FormShowEmployees(allEmployees);
            }
            else if (radioButtonSurname.Checked)
            {
                if(comboBoxSurname.Text != "")
                {
                    List<BasicEmployee> employeesBySurname = DataMan.getBasicEmployeesBySurname(
                                                             comboBoxSurname.Text);
                    form = new FormShowEmployees(employeesBySurname);
                }
                else
                {
                    showErrorMessage(radioButtonSurname.Text);
                    return;
                }
                
            }
            else
            {
                if (comboBoxDepartment.Text != "")
                {
                    List<BasicEmployee> employeesByDepartment = DataMan.getBasicEmployeesByDepartment(
                                                                comboBoxDepartment.Text);
                    form = new FormShowEmployees(employeesByDepartment);
                }
                else
                {
                    showErrorMessage(radioButtonDepartment.Text);
                    return;
                }
            }
            
            this.Dispose();
            form.Show();
            
        }

        private void showErrorMessage(string text)
        {
            MessageBox.Show($"{text} cannot be empty!!");
        }

        private void radioButtonSurname_CheckedChanged(object sender, EventArgs e)
        {
            comboBoxSurname.Text = "";
            if (radioButtonSurname.Checked)
            {
                List<String> surnames =  DataMan.getSurnames();
                FieldsInteractionManager.fillComboboxWithValues(surnames,comboBoxSurname);
            }
        }

        private void radioButtonDepartment_CheckedChanged(object sender, EventArgs e)
        {
            
            comboBoxDepartment.Text = "";
            if (radioButtonDepartment.Checked)
            {
                FieldsInteractionManager.fillComboboxWithValues(Department.getDepartments(), comboBoxDepartment);
            }
            

        }
    }
}
