﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Linq;

namespace Firma
{
    class AddDataManager : DataManager, IDataInteraction
    {
        public AddDataManager() : base()
        {

        }
       
        public void addNewDepartment(string departmentName)
        {
            string querySQL = "INSERT INTO Department (Department)" +
                             " Values (@Department)";
            try
            {
                Conn.Open();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@Department", departmentName);
                cmd.ExecuteNonQuery();
                Conn.Close();
            }
            catch (Exception e)
            {
                showErrorAndCloseConnection(departmentName, e.Message);
            }
        }

        public void addNewDirector(Director director)
        {
            int empID = addNewEmployee(director);
            string querySQL = "INSERT INTO Director (RoomNumber, EmployeeID)" +
                              " Values (@RoomNumber, @EmployeeID)";

            try
            {
                Conn.Open();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@RoomNumber", director.RoomNumber);
                cmd.Parameters.AddWithValue("@EmployeeID", empID);
                cmd.ExecuteNonQuery();
                Conn.Close();
            }
            catch (Exception e)
            {
                showErrorAndCloseConnection(director.EmployeePosition, e.Message);
            }
        }

        public void addNewAsistant(Asistant asistant)
        {
            int empID = addNewEmployee(asistant);
            string querySQL = "INSERT INTO Assistant (PhoneNumber, EmployeeID)" +
                              " Values (@PhoneNumber, @EmployeeID)";

            try
            {
                Conn.Open();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@PhoneNumber", asistant.PhoneNumber);
                cmd.Parameters.AddWithValue("@EmployeeID", empID);
                cmd.ExecuteNonQuery();
                Conn.Close();
            }
            catch (Exception e)
            {
                showErrorAndCloseConnection(asistant.EmployeePosition, e.Message);
            }
        }

        private void showErrorAndCloseConnection(string position, string errorMessage)
        {
            MessageBox.Show($"Cannot add {position}!!! {Environment.NewLine}" +
                                $"{errorMessage}");
            Conn.Close();
        }
        public int addNewEmployee(Employee employee)
        {
            int addressID = addNewAddress(employee.Address);
            int empDataID = addNewEmployeeData(employee.EmployeeData);
            int empID = addEmployeeWithGeneratedIDs(employee, addressID, empDataID);
            employee.EmployeeID = empID;
            return empID;
        }

        private int addEmployeeWithGeneratedIDs(Employee employee, int addressID, int empDataID)
        {
            string querySQL = "INSERT INTO Employee (EmployeeName, Surname, BirthDate, EmployeePosition," +
                              "EmployeeDataID, AddressID)" +
                              " Values (@EmployeeName, @Surname, @BirthDate, @EmployeePosition," +
                              "@EmployeeDataID, @AddressID)";
            try
            {
                Conn.Open();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@EmployeeName", employee.EmployeeName);
                cmd.Parameters.AddWithValue("@Surname", employee.Surname);
                cmd.Parameters.AddWithValue("@BirthDate", employee.BirthDate);
                cmd.Parameters.AddWithValue("@EmployeePosition", employee.EmployeePosition);
                cmd.Parameters.AddWithValue("@EmployeeDataID", empDataID);
                cmd.Parameters.AddWithValue("@AddressID", addressID);
                cmd.ExecuteNonQuery();
                Conn.Close();

                List<string> maxID = recordsetToList("SELECT MAX(ID) FROM Employee");
                return Convert.ToInt32(maxID.First());

            }
            catch (Exception e)
            {
                showErrorAndCloseConnection(employee.EmployeePosition, e.Message);
                return -1;
            }
        }

            private int addNewEmployeeData(EmployeeData employeeData)
        {
            string querySQL = "INSERT INTO EmployeeData (DepartmentID, EmploymentDate, Salary)" +
                              " Values (@DepartmentID, @EmploymentDate, @Salary)";
            int depID = getDepartmentIDByName(employeeData.Department);

            try
            {
                Conn.Open();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@DepartmentID", depID);
                cmd.Parameters.AddWithValue("@EmploymentDate", employeeData.EmploymentDate);
                cmd.Parameters.AddWithValue("@Salary", employeeData.Salary);
                cmd.ExecuteNonQuery();
                Conn.Close();
                List<string> maxID = recordsetToList("SELECT MAX(ID) FROM EmployeeData");
                return Convert.ToInt32(maxID.First());
            }
            catch (Exception e)
            {
                showErrorAndCloseConnection("employee data", e.Message);
                return -1;
            }

        }
        private int getDepartmentIDByName(string department)
        {
            string querySQL = $"SELECT ID FROM Department WHERE Department='{department}'";
            List<string> depID = recordsetToList(querySQL);
            return Convert.ToInt32(depID.First());

        }
        private int addNewAddress(Address adres)
        {
            string querySQL = "INSERT INTO Address (City, Street, ZipCode)" +
                              " Values (@City, @Street, @ZipCode)";
            try
            {
                Conn.Open();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@City", adres.City);
                cmd.Parameters.AddWithValue("@Street", adres.Street);
                cmd.Parameters.AddWithValue("@ZipCode", adres.ZipCode);
                cmd.ExecuteNonQuery();
                Conn.Close();
                List<string> maxID = recordsetToList("SELECT MAX(ID) FROM Address");
                return Convert.ToInt32(maxID.First());
            }
            catch (Exception e)
            {
                showErrorAndCloseConnection("address", e.Message);
                return -1;
            }
        }
    }


}
