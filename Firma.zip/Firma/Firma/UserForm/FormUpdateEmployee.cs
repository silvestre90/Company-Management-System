﻿using Firma.CRUD;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Firma
{   //todo - koniecznie dodaj walidacje na Kod Pocztowy, zeby zeskalowac swoje rozwiazanie
    //opcjonalnie dodaj metody walidujace wpisy uzytkownika korzystajac z FieldsInteractionManagera
    //Czysc pola po dodaniu pracownika
    //Dodaj ShowDepartmentHierarchy, CheckForBirthday, PromoteEmployeeRandomly
    //refactor kodu pod guzikiem OK w tej klasie
    //zmienne przypisane na sztywno trzeba bedzie przeniesc do Const
    public partial class FormUpdateEmployee : Form
    {
        IGetable DataMan;
        public FormUpdateEmployee()
        {
            InitializeComponent();
            
        }

        public FormUpdateEmployee(Employee employee)
        {
            InitializeComponent();
            DataMan = new DisplayDataManager();
            FillFieldsWithInitialValues(employee);
            
            
        }

        private void FillFieldsWithInitialValues(Employee employee)
        {
            this.lblNameSurname.Text = $"Update {employee.EmployeeName} {employee.Surname}";
            this.lblID.Text = employee.EmployeeID.ToString();

            cmbPosition.DataSource = Enum.GetValues(typeof(Position));
            cmbPosition.Text = employee.EmployeeData.EmployeePosition;

            textBoxName.Text = employee.EmployeeName;
            textBoxSurname.Text = employee.Surname;
            textBoxSalary.Text = employee.EmployeeData.Salary.ToString();

            textBoxZipCode.Text = employee.Address.ZipCode;
            textBoxCity.Text = employee.Address.City;
            textBoxStreet.Text = employee.Address.Street;
         
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            CRUD.IUpdatable UpdateManager = new UpdateDataManager();
            Employee emp = DataMan.GetEmployeeById(Convert.ToInt32(lblID.Text));

            Address address = new Address(textBoxCity.Text, textBoxStreet.Text, textBoxZipCode.Text);
            UpdateManager.UpdateAddress(emp, address);

            EmployeeData empData = new EmployeeData(Convert.ToInt32(textBoxSalary.Text),
                                                    cmbPosition.Text);
            UpdateManager.UpdateEmployeeData(emp, empData);

            Dictionary<String, String> dict = new Dictionary<string, string>();
            dict.Add("Name", textBoxName.Text);
            dict.Add("Surname", textBoxSurname.Text);

            UpdateManager.UpdateEmployee(emp, dict);
            showSuccessMessage();
            this.Dispose();
        }

        private void showSuccessMessage()
        {
            MessageBox.Show("Employee data updated");
        }

        private void FormUpdateEmployee_Load(object sender, EventArgs e)
        {

        }

        private void textBoxZipCode_TextChanged(object sender, EventArgs e)
        {
            FieldsInteractionManager.setCorrectColor(textBoxZipCode);

            if (textBoxZipCode.Text != "")
            {

                if (!FieldsValidator.ZipFieldCorrectlyFilled(textBoxZipCode.Text))
                {
                    FieldsInteractionManager.setErrorColor(textBoxZipCode);
                }
            }
            else
            {
                FieldsInteractionManager.setNeutralColor(this);
            }
        }
    }
}
