﻿namespace Firma
{
    partial class FormChooseParameterToFilter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOK = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButtonAll = new System.Windows.Forms.RadioButton();
            this.radioButtonSurname = new System.Windows.Forms.RadioButton();
            this.radioButtonDepartment = new System.Windows.Forms.RadioButton();
            this.comboBoxSurname = new System.Windows.Forms.ComboBox();
            this.comboBoxDepartment = new System.Windows.Forms.ComboBox();
            this.btnShowHierarchy = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(137, 167);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(121, 40);
            this.btnOK.TabIndex = 1;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Choose parameter or select all";
            // 
            // radioButtonAll
            // 
            this.radioButtonAll.AutoSize = true;
            this.radioButtonAll.Checked = true;
            this.radioButtonAll.Location = new System.Drawing.Point(13, 46);
            this.radioButtonAll.Name = "radioButtonAll";
            this.radioButtonAll.Size = new System.Drawing.Size(44, 21);
            this.radioButtonAll.TabIndex = 3;
            this.radioButtonAll.TabStop = true;
            this.radioButtonAll.Text = "All";
            this.radioButtonAll.UseVisualStyleBackColor = true;
            // 
            // radioButtonSurname
            // 
            this.radioButtonSurname.AutoSize = true;
            this.radioButtonSurname.Location = new System.Drawing.Point(13, 82);
            this.radioButtonSurname.Name = "radioButtonSurname";
            this.radioButtonSurname.Size = new System.Drawing.Size(86, 21);
            this.radioButtonSurname.TabIndex = 4;
            this.radioButtonSurname.Text = "Surname";
            this.radioButtonSurname.UseVisualStyleBackColor = true;
            this.radioButtonSurname.CheckedChanged += new System.EventHandler(this.radioButtonSurname_CheckedChanged);
            // 
            // radioButtonDepartment
            // 
            this.radioButtonDepartment.AutoSize = true;
            this.radioButtonDepartment.Location = new System.Drawing.Point(12, 118);
            this.radioButtonDepartment.Name = "radioButtonDepartment";
            this.radioButtonDepartment.Size = new System.Drawing.Size(103, 21);
            this.radioButtonDepartment.TabIndex = 5;
            this.radioButtonDepartment.Text = "Department";
            this.radioButtonDepartment.UseVisualStyleBackColor = true;
            this.radioButtonDepartment.CheckedChanged += new System.EventHandler(this.radioButtonDepartment_CheckedChanged);
            // 
            // comboBoxSurname
            // 
            this.comboBoxSurname.FormattingEnabled = true;
            this.comboBoxSurname.Location = new System.Drawing.Point(137, 82);
            this.comboBoxSurname.Name = "comboBoxSurname";
            this.comboBoxSurname.Size = new System.Drawing.Size(121, 24);
            this.comboBoxSurname.TabIndex = 6;
            // 
            // comboBoxDepartment
            // 
            this.comboBoxDepartment.FormattingEnabled = true;
            this.comboBoxDepartment.Location = new System.Drawing.Point(137, 118);
            this.comboBoxDepartment.Name = "comboBoxDepartment";
            this.comboBoxDepartment.Size = new System.Drawing.Size(121, 24);
            this.comboBoxDepartment.TabIndex = 7;
            this.comboBoxDepartment.SelectedIndexChanged += new System.EventHandler(this.comboBoxDepartment_SelectedIndexChanged);
            // 
            // btnShowHierarchy
            // 
            this.btnShowHierarchy.Enabled = false;
            this.btnShowHierarchy.Location = new System.Drawing.Point(137, 225);
            this.btnShowHierarchy.Name = "btnShowHierarchy";
            this.btnShowHierarchy.Size = new System.Drawing.Size(121, 40);
            this.btnShowHierarchy.TabIndex = 8;
            this.btnShowHierarchy.Text = "Show Hierarchy";
            this.btnShowHierarchy.UseVisualStyleBackColor = true;
            this.btnShowHierarchy.Click += new System.EventHandler(this.btnShowHierarchy_Click);
            // 
            // FormChooseParameterToFilter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(265, 269);
            this.Controls.Add(this.btnShowHierarchy);
            this.Controls.Add(this.comboBoxDepartment);
            this.Controls.Add(this.comboBoxSurname);
            this.Controls.Add(this.radioButtonDepartment);
            this.Controls.Add(this.radioButtonSurname);
            this.Controls.Add(this.radioButtonAll);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnOK);
            this.Name = "FormChooseParameterToFilter";
            this.Text = "Choose Parameters";
            this.Load += new System.EventHandler(this.FormChooseParameterToFilter_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButtonAll;
        private System.Windows.Forms.RadioButton radioButtonSurname;
        private System.Windows.Forms.RadioButton radioButtonDepartment;
        private System.Windows.Forms.ComboBox comboBoxSurname;
        private System.Windows.Forms.ComboBox comboBoxDepartment;
        private System.Windows.Forms.Button btnShowHierarchy;
    }
}