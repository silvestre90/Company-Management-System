﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace Firma
{
    public partial class FormShowEmployees : Form
    {
        
        public FormShowEmployees(List<Employee> employees)
        {
            InitializeComponent();
            listView1.Items.Clear();            

            foreach (Employee e in employees)
            {
                var item = new ListViewItem(new[] { e.EmployeeName, e.Surname, e.EmployeeData.Department, e.EmployeeData.EmployeePosition});
                listView1.Items.Add(item);
            }
            listView1.Update();
        }
    }
}
