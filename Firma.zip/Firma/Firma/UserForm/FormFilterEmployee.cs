﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Firma
{
    public partial class FormFilterEmployee : Form
    {
        private DisplayDataManager DataMan;

        public FormFilterEmployee()
        {
            InitializeComponent();
            DataMan = new DisplayDataManager();
        }

        public FormFilterEmployee(string workMode)
        {
            InitializeComponent();
            DataMan = new DisplayDataManager();
            this.Text = workMode;
        }

        private void FormFilterEmployee_Load(object sender, EventArgs e)
        {

            
            FieldsInteractionManager.fillComboboxWithValues(Department.getDepartments(), cmbDepartment);
        }

        private void cmbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {

            cmbSurname.Items.Clear();
            cmbSurname.Text = "";
            cmbID.Items.Clear();
            cmbID.Text = "";
            cmbID.Enabled = false;

            if(cmbDepartment.Text != "")
            {
                List<String> surnames = DataMan.GetSurnamesByDepartment(cmbDepartment.Text);
                FieldsInteractionManager.fillComboboxWithValues(surnames, cmbSurname);
            }
        }
        private void cmbSurname_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbID.Items.Clear();
            cmbID.Text = "";
            cmbID.Enabled = false;

            if (cmbDepartment.Text != "")
            {
                List<int> empIDsList = DataMan.GetSearchedEmployeeID(cmbDepartment.Text, cmbSurname.Text);
                int listSize = empIDsList.Count;
                if (listSize > 1)
                {
                    List<String> empIDListToString = new List<string>();
                    foreach (int item in empIDsList)
                    {
                        empIDListToString.Add(item.ToString());
                    }
                    cmbID.Enabled = true;
                    FieldsInteractionManager.fillComboboxWithValues(empIDListToString, cmbID);
                }
            }
            
        }

        private void cmbID_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnOK_Click(object sender, EventArgs e)
        {   //todo - wyskakuje exception przy probie wyswietlenia pracownikow, trzeba zdebugowac
            if (cmbDepartment.Text == "" || cmbSurname.Text == "")
            {
                MessageBox.Show("One of required fields is empty!!!");
            }
            else
            {
                
                    Employee employee = GetEmployeeByFilledData();
                    ChooseCorrectAction(employee);
                    ResetFieldsStatus();
            }
        }

        private void ResetFieldsStatus()
        {
            cmbDepartment.Text = "";

            cmbSurname.Items.Clear();
            cmbSurname.Text = "";

            if (cmbID.Enabled)
            {
                cmbID.Items.Clear();
                cmbID.Text = "";
                cmbID.Enabled = false;
            }
        }

        private Employee GetEmployeeByFilledData()
        {
            Employee emp;
            if (this.cmbID.Text == "")
            {
                emp =  DataMan.GetEmployeeBySurnameAndDepartment(cmbDepartment.Text,
                                             cmbSurname.Text);
            }
            else
            {
                emp = DataMan.GetEmployeeById(Convert.ToInt32(cmbID.Text));
            }
            return emp;
        }

        private void ChooseCorrectAction(Employee employee)
        {
            
            if(this.Text == FormMain.RemovalMode)
            {
                CRUD.IRemovable removeManager = new RemoveDataManager();
                try
                {
                    removeManager.RemoveEmployee(employee);
                    MessageBox.Show($"{employee.EmployeeName} {employee.Surname} from {employee.EmployeeData.Department} was removed");
                }
                catch (Exception)
                {

                }                
            }else if(this.Text == FormMain.EditMode)
            {
                FormUpdateEmployee formUpdate = new FormUpdateEmployee(employee);
                formUpdate.Show();
            }
        }
    }
}
