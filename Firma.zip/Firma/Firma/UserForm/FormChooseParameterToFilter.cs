﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Firma
{
    public partial class FormChooseParameterToFilter : Form
    {
        CRUD.IGetable DataMan;
        public FormChooseParameterToFilter()
        {
            DataMan = new DisplayDataManager();
            InitializeComponent();
        }

        private void FormChooseParameterToFilter_Load(object sender, EventArgs e)
        {

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            FormShowEmployees form;
            if (radioButtonAll.Checked)
            {
                List<Employee> allEmployees = DataMan.GetAllEmployees();
                form = new FormShowEmployees(allEmployees);
            }
            else if (radioButtonSurname.Checked)
            {
                if(comboBoxSurname.Text != "")
                {
                    List<Employee> employeesBySurname = DataMan.GetEmployeesBySurname(
                                                             comboBoxSurname.Text);
                    form = new FormShowEmployees(employeesBySurname);
                }
                else
                {
                    showErrorMessage(radioButtonSurname.Text);
                    return;
                }
                
            }
            else
            {
                if (comboBoxDepartment.Text != "")
                {
                    List<Employee> employeesByDepartment = DataMan.GetEmployeesByDepartment(
                                                                comboBoxDepartment.Text);
                    form = new FormShowEmployees(employeesByDepartment);
                }
                else
                {
                    showErrorMessage(radioButtonDepartment.Text);
                    return;
                }
            }
            
            this.Dispose();
            form.Show();
            
        }

        private void showErrorMessage(string text)
        {
            MessageBox.Show($"{text} cannot be empty!!");
        }

        private void radioButtonSurname_CheckedChanged(object sender, EventArgs e)
        {
            comboBoxSurname.Text = "";
            if (radioButtonSurname.Checked)
            {
                List<String> surnames =  DataMan.GetAllSurnames();
                FieldsInteractionManager.fillComboboxWithValues(surnames,comboBoxSurname);
            }
        }

        private void radioButtonDepartment_CheckedChanged(object sender, EventArgs e)
        {
            
            comboBoxDepartment.Text = "";
            if (radioButtonDepartment.Checked)
            {
                FieldsInteractionManager.fillComboboxWithValues(Department.getDepartments(), comboBoxDepartment);
            }
            else
            {
                btnShowHierarchy.Enabled = false;
            }
            

        }

        private void comboBoxDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBoxDepartment.Text != "")
            {
                btnShowHierarchy.Enabled = true;
            }
        }

        private void btnShowHierarchy_Click(object sender, EventArgs e)
        {
            if (comboBoxDepartment.Text != "")
            {
                List<Employee> employeesHierarchy = DataMan.GetDepartmentHierarchy(comboBoxDepartment.Text);
                FormShowEmployees form = new FormShowEmployees(employeesHierarchy);
                this.Dispose();
                form.Show();
            }
            else
            {
                showErrorMessage(radioButtonDepartment.Text);
                return;
            }

            
        }
    }
}
