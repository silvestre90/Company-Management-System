﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma
{
    public class EmployeeData
    {
        public string Department { get; set; }
        public DateTime EmploymentDate { get; set; }
        public double Salary { get; set; }

        public EmployeeData(string department, DateTime employmentDate, double salary)
        {
            Department = department;
            EmploymentDate = employmentDate;
            Salary = salary;
        }
    }
}
