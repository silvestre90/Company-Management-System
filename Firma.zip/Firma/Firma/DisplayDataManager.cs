﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma
{
    class DisplayDataManager : DataManager
    {
        public DisplayDataManager() : base()
        {

        }

        //public List<BasicEmployee> getAllBasicEmployeeInfoToList()
        //{
        //    string qry = "SELECT Employee.ID, Employee.EmployeeName, Employee.Surname," +
        //                 " Employee.EmployeePosition, Department.Department" +
        //                 " FROM Department INNER JOIN" +
        //                 "(EmployeeData INNER JOIN Employee ON EmployeeData.ID = Employee.EmployeeDataID)" +
        //                 " ON Department.ID = EmployeeData.DepartmentID";

        //    Conn.Open();
        //    OleDbCommand cmd = new OleDbCommand(qry, Conn);
        //    OleDbDataReader reader = cmd.ExecuteReader();

        //    List<BasicEmployee> recordsList = new List<BasicEmployee>();
        //    while (reader.Read())
        //    {
        //        recordsList.Add(new BasicEmployee(Convert.ToInt32(reader[0].ToString()),
        //                        reader[1].ToString(),reader[2].ToString(),reader[3].ToString(),
        //                        reader[4].ToString()));
        //    }
        //    Conn.Close();
        //    return recordsList;
        //}

        //internal List<int> getSearchedEmployeeID(string department, string surname)
        //{
        //    List<BasicEmployee> employees = getAllBasicEmployeeInfoToList();

        //    List<int> employeeIDs = (from e in employees
        //                             where e.Surname == surname && e.Department == department
        //                             select e.EmployeeID).ToList();
        //    return employeeIDs;
        //}

        internal List<String> getSurnamesByDepartment(string department)
        {
            List<BasicEmployee> employeesByDepartment = getBasicEmployeesByDepartment(department);
            List<string> surnames = (from e in employeesByDepartment select e.Surname).Distinct().ToList();
            return surnames;
        }

        internal List<BasicEmployee> getBasicEmployeesBySurname(string surname)
        {
            List<BasicEmployee> employees = getAllBasicEmployeeInfoToList();
            
            List<BasicEmployee> employeesBySurname = employees.FindAll(BasicEmployee =>
                                                     BasicEmployee.Surname == surname);

            return employeesBySurname;
        }

        internal List<String> getSurnames()
        {
            List<String> surnames = recordsetToList("SELECT DISTINCT Surname FROM Employee");
            return surnames;
        }

        internal List<BasicEmployee> getBasicEmployeesByDepartment(string department)
        {
            List<BasicEmployee> employees = getAllBasicEmployeeInfoToList();

            List<BasicEmployee> employeesByDepartment = employees.FindAll(BasicEmployee =>
                                                     BasicEmployee.Department == department);

            return employeesByDepartment;
        }

        internal BasicEmployee getEmployeeBySurnameAndDepartment(string department, string surname)
        {
            List<BasicEmployee> employees = getAllBasicEmployeeInfoToList();
            BasicEmployee employee = employees.Find(BasicEmployee => BasicEmployee.Department == department
                                                    && BasicEmployee.Surname == surname);
            return employee;
                                                        
        }

        internal BasicEmployee getEmployeeById(int empID)
        {
            List<BasicEmployee> employees = getAllBasicEmployeeInfoToList();
            BasicEmployee employee = (from e in employees where e.EmployeeID == empID select e).First();
            return employee;
        }
    }
}
