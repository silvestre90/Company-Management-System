﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Windows.Forms;

namespace Firma
{
    static class FieldsValidator
    {

        public static DateTime FirstDate = new DateTime(1990, 1, 1);
        
            public static bool valueMatchesRegex(string reg, string text)
        {
            Regex regex = new Regex(reg);
            if (regex.IsMatch(text))
            {
                return true;
            }

            return false;
        }
        
        public static bool primaryFieldValid(Control control)
        {
            if(control.BackColor == FieldsInteractionManager.CorrectColor)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool dateFieldValid(DateTimePicker dateTimePicker)
        {
            if(dateTimePicker.Value == FirstDate)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static bool isEmployeeDataValid(List<Control> textBoxesList, List<DateTimePicker> datesList)
        {
            foreach (Control textBox in textBoxesList)
            {
                if (!primaryFieldValid(textBox))
                {
                    return false;
                }
            }

            foreach (DateTimePicker dateField in datesList)
            {
                if (!dateFieldValid(dateField))
                {
                    return false;
                }
            }

            return true;
        }

        internal static void showErrorMessage(string employeePosition)
        {
            MessageBox.Show($"At least one of required fields is empty or has validation errors." +
                Environment.NewLine +
                $"{employeePosition} cannot be added");
        }
    }
}
