﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Linq;


namespace Firma
{
    public abstract class DataManager
    {

        public OleDbConnection Conn;
        private const string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;" +
                @"Data source= C:\C#\Firma\repos\Firma\appdata\Firma.accdb";

        protected DataManager()
        {
            Conn = createConnection();
        }

        public List<String> recordsetToList(string qry)
        {
            
            Conn.Open();
            OleDbCommand cmd = new OleDbCommand(qry, Conn);
            OleDbDataReader reader = cmd.ExecuteReader();

            List<string> recordsList = new List<string>();
            while (reader.Read())
            {
                recordsList.Add(reader[0].ToString());
            }
            Conn.Close();
            return recordsList;
        }

        public List<string> getDepartments()
        {
            List<String> depsList = recordsetToList("SELECT Department FROM Department");
            return depsList;
        }

        public List<int> getSearchedEmployeeID(string department, string surname)
        {
            List<BasicEmployee> employees = getAllBasicEmployeeInfoToList();

            List<int> employeeIDs = (from e in employees
                                     where e.Surname == surname && e.Department == department
                                     select e.EmployeeID).ToList();
            return employeeIDs;
        }

        public List<BasicEmployee> getAllBasicEmployeeInfoToList()
        {
            string qry = "SELECT Employee.ID, Employee.EmployeeName, Employee.Surname," +
                         " Employee.EmployeePosition, Department.Department," +
                         " Employee.AddressID, Employee.EmployeeDataId" +
                         " FROM Department INNER JOIN" +
                         "(EmployeeData INNER JOIN Employee ON EmployeeData.ID = Employee.EmployeeDataID)" +
                         " ON Department.ID = EmployeeData.DepartmentID";

            Conn.Open();
            OleDbCommand cmd = new OleDbCommand(qry, Conn);
            OleDbDataReader reader = cmd.ExecuteReader();

            List<BasicEmployee> recordsList = new List<BasicEmployee>();
            while (reader.Read())
            {
                recordsList.Add(new BasicEmployee(Convert.ToInt32(reader[0].ToString()),
                                reader[1].ToString(), reader[2].ToString(), reader[3].ToString(),
                                reader[4].ToString(), Convert.ToInt32(reader[5].ToString()),
                                Convert.ToInt32(reader[6].ToString())));
            }
            Conn.Close();
            return recordsList;
        }

        public OleDbConnection createConnection()
        {
            OleDbConnection conn = new OleDbConnection();

            conn.ConnectionString = connectionString;

            try
            {
                conn.Open();
                conn.Close();
                return conn;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                conn.Close();
                return null;
            }
        }
    }
}
