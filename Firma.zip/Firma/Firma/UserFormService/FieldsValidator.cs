﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Windows.Forms;

namespace Firma
{
    static class FieldsValidator
    {

        public static DateTime FirstDate = new DateTime(1985, 1, 1);
        
            public static bool ValueMatchesRegex(string reg, string text)
        {
            Regex regex = new Regex(reg);
            return regex.IsMatch(text) ? true : false;
            
        }
        
        public static bool ZipFieldCorrectlyFilled(string text)
        {
            string regexPattern = @"^(\d{2}-\d{3})$";
            return ValueMatchesRegex(regexPattern, text);
        }

        public static bool SalaryFieldCorrectlyFilled(string text)
        {
            string regexPattern = @"^[1-9]{1}[0-9]{4,6}$";
            return ValueMatchesRegex(regexPattern, text);
        }

        public static bool PhoneFieldCorrectlyFilled(string text)
        {
            string regexPattern = @"^[1-9]{1}(\d){8}$";
            return ValueMatchesRegex(regexPattern, text);
        }

        public static bool PrimaryFieldValid(Control control)
        {
            return control.BackColor == FieldsInteractionManager.CorrectColor ? true : false;

            //if(control.BackColor == FieldsInteractionManager.CorrectColor)
            //{
            //    return true;
            //}
            //else
            //{
            //    return false;
            //}
        }

        public static bool DateFieldValid(DateTimePicker dateTimePicker)
        {
            return dateTimePicker.Value == FirstDate ? false : true;

            //if (dateTimePicker.Value == FirstDate)
            //{
            //    return false;
            //}
            //else
            //{
            //    return true;
            //}
        }

        public static bool IsEmployeeDataValid(List<Control> textBoxesList, List<DateTimePicker> datesList)
        {
            foreach (Control textBox in textBoxesList)
            {
                if (!PrimaryFieldValid(textBox))
                {
                    return false;
                }
            }

            foreach (DateTimePicker dateField in datesList)
            {
                if (!DateFieldValid(dateField))
                {
                    return false;
                }
            }

            return true;
        }

        internal static void ShowErrorMessage(string employeePosition)
        {
            MessageBox.Show($"At least one of required fields is empty or has validation errors." +
                Environment.NewLine +
                $"{employeePosition} cannot be added");
        }
    }
}
