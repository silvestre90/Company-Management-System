﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Firma
{
    static class FieldsInteractionManager
    {
        public static Color Creamy = Color.FromArgb(255, 255, 253);
        public static Color CorrectColor = Color.White;

        public static void setCreamyColor(Control control)
        {
            control.BackColor = Creamy;
        }
        public static void setCorrectColor(Control control)
        {
            control.BackColor = CorrectColor;
        }

        public static void setNeutralColor(Control control)
        {
            control.BackColor = Color.LightGray;
        }

        public static void setErrorColor(Control control)
        {
            control.BackColor = Color.Red;
        }

        public static void performDefaultValidation(Control control)
        {
            setCorrectColor(control);

            if (control.Text.Length == 0)
            {
                setNeutralColor(control);
            }
        }

        private static void clearTextFromChildren(TabControl tabControl)
        {
            foreach (Object o in tabControl.TabPages)
            {
                checkAndClearSingleObject(o);
            }
        }

        private static void checkAndClearSingleObject(Object o)
        {
            if(o.GetType() == typeof(TabPage))
            {
                TabPage tabPage = (TabPage)o;
                foreach (Object obj in tabPage.Controls)
                {
                    checkAndClearSingleObject(obj);
                }
                
            }
            if (o.GetType() == typeof(TextBox))
            {
                TextBox textBox = (TextBox)o;
                textBox.Text = "";
            }else if(o.GetType() == typeof(ComboBox))
            {
                ComboBox comboBox = (ComboBox)o;
                comboBox.Text = "";
            }
        }
        public static void clearAllTextBoxes(Form form)
        {
           
            foreach (Object o in form.Controls)
            {
                if(o.GetType() == typeof(TabControl))
                {
                    clearTextFromChildren((TabControl)o);
                }
                checkAndClearSingleObject(o);
            }
        }

        public static void clearTextComboBoxes(Form form)
        {
            
            foreach (Object o in form.Controls)
            {
                if (o.GetType() == typeof(TabControl))
                {
                    clearTextFromChildren((TabControl)o);
                }
                checkAndClearSingleObject(o);
            }
        }

        public static void resetAllComboBoxes(TabControl tabControl)
        {
            foreach (Object o in tabControl.Controls)
            {
                if (o.GetType() == typeof(ComboBox))
                {
                    ComboBox cmbBox = (ComboBox)o;
                    cmbBox.Items.Clear();
                }
            }
        }
        public static void resetAllComboBoxes(Form form)
        {
            clearTextComboBoxes(form);
            foreach (Object o in form.Controls)
            {
                if (o.GetType() == typeof(ComboBox))
                {
                    ComboBox cmbBox = (ComboBox)o;
                    cmbBox.Items.Clear();
                }
            }
        }

        public static void fillComboboxWithValues(List<String> cmbItems, ComboBox comboBox)
        {
            comboBox.Items.Clear();

            foreach (var item in cmbItems)
            {
                 comboBox.Items.Add(item);
            }
        }
    }
}
