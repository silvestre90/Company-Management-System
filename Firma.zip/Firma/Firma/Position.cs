﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma
{
    public enum Position
    {
        employee = 1, asistant=2, manager=3,director=4
    }
}
