﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string Surname { get; set; }
        public DateTime BirthDate { get; set; }

        public string EmployeePosition { get; set; }
        public EmployeeData EmployeeData;
        public Address Address;

        public Employee(string name, string surname, DateTime birthDate, string employeePosition,
                        EmployeeData empData, Address address)
            //todo - stworzyc interfejs BasicEmployee z polami potrzebnymi do wyciagniecia na display
        {
            EmployeeName = name;
            Surname = surname;
            BirthDate = birthDate;
            EmployeePosition = employeePosition;
            EmployeeData = empData;
            Address = address;
        }

        public Employee(string name, string surname, DateTime birthDate, EmployeeData empData, Address adres)
        {
            EmployeeName = name;
            Surname = surname;
            BirthDate = birthDate;
            EmployeeData = empData;
            Address = adres;
        }
    }
}
