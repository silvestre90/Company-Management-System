﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma
{
    
    public class Asistant:Employee
    {
        public string PhoneNumber { get; set; }

        public Asistant(string phoneNumber, string imie, string nazwisko, DateTime dataUrodzenia,
                        EmployeeData danePracy, Address adres) : base(
                        imie, nazwisko, dataUrodzenia, danePracy, adres)
        {
            PhoneNumber = phoneNumber;
            EmployeePosition = Position.asistant.ToString();
        }

        public Asistant(string phoneNumber, Employee emp) : base(emp.EmployeeName, emp.Surname,
                        emp.BirthDate, emp.EmployeeData, emp.Address)
        {
            PhoneNumber = phoneNumber;
            EmployeePosition = Position.asistant.ToString();
        }
    }
}
