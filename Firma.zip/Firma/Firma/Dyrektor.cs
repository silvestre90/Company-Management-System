﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma
{
    public class Director:Employee
    {
        public int RoomNumber { get; set; }

        public Director(int roomNumber, string name, string surname, DateTime birthDate, EmployeeData empData,
                        Address address ) : base(name,surname, birthDate, empData,address)
        {
            EmployeePosition = Position.director.ToString();
            RoomNumber = roomNumber;
        }

        public Director(int roomNumber, Employee emp): base(emp.EmployeeName, emp.Surname,
                        emp.BirthDate, emp.EmployeeData, emp.Address)
        {
            EmployeePosition = Position.director.ToString();
            RoomNumber = roomNumber;
        }
    }
}
