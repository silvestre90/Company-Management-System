﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma
{
    public class Department
    {
        public List<String> departments  { get; set; }


        public static List<String> getDepartments()
        {
            Department dep = new Department();
            return dep.departments;
        }
        public List<String> returnUpdatedList(string newDepartment)
        {
            AddDataManager man = new AddDataManager();
            man.AddNewDepartment(newDepartment);


            departments.Add(newDepartment);
            return departments;
        }
        public Department()
        {
            departments = new List<string>();
            AddDataManager man = new AddDataManager();
            departments = man.GetDepartments();
        }
    }
}
