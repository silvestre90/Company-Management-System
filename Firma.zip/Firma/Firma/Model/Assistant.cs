﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma
{
    
    public class Assistant:Employee
    {
        public string PhoneNumber { get; set; }

        public Assistant(string phoneNumber, string imie, string nazwisko, DateTime dataUrodzenia,
                        EmployeeData danePracy, Address adres) : base(
                        imie, nazwisko, dataUrodzenia, danePracy, adres)
        {
            PhoneNumber = phoneNumber;
            this.EmployeeData.EmployeePosition = Position.asistant.ToString();
        }

        public Assistant(string phoneNumber, Employee emp) : base(emp.EmployeeName, emp.Surname,
                        emp.BirthDate, emp.EmployeeData, emp.Address)
        {
            PhoneNumber = phoneNumber;
            this.EmployeeData.EmployeePosition = Position.asistant.ToString();
        }
    }
}
