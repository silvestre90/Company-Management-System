﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma
{
    public class EmployeeData
    {

        public int Id { get; set; }
        public string Department { get; set; }
        public DateTime EmploymentDate { get; set; }
        public double Salary { get; set; }
        public string EmployeePosition { get; set; }

        public EmployeeData(string department, DateTime employmentDate, double salary, string employeePosition)
        {
            EmployeePosition = employeePosition;
            Department = department;
            EmploymentDate = employmentDate;
            Salary = salary;
        }

        public EmployeeData(double salary, string employeePosition)
        {
            Salary = salary;
            EmployeePosition = employeePosition;
        }
    }
}
