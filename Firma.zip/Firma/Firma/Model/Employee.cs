﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string Surname { get; set; }
        public DateTime BirthDate { get; set; }
        public EmployeeData EmployeeData;
        public Address Address;

        public override string ToString()
        {
            return ($"{this.EmployeeName}, {this.Surname}, {this.BirthDate.ToString()}");
        }

        public Employee()
        {

        }
        public Employee(int id,string name, string surname, DateTime birthDate,
                       EmployeeData empData, Address address)
        {
            EmployeeID = id;
            EmployeeName = name;
            Surname = surname;
            BirthDate = birthDate;
            EmployeeData = empData;
            Address = address;
        }


        public Employee(string name, string surname, DateTime birthDate,
                        EmployeeData empData, Address address)
        {
            EmployeeName = name;
            Surname = surname;
            BirthDate = birthDate;
            EmployeeData = empData;
            Address = address;
        }

     
    }
}
