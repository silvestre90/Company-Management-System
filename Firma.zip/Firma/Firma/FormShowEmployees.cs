﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace Firma
{
    public partial class FormShowEmployees : Form
    {
        
        public FormShowEmployees(List<BasicEmployee> employees)
        {
            InitializeComponent();
            listView1.Items.Clear();            

            foreach (BasicEmployee e in employees)
            {
                var item = new ListViewItem(new[] { e.Name, e.Surname, e.Department, e.EmployeePosition});
                listView1.Items.Add(item);
            }
            listView1.Update();
        }
    }
}
