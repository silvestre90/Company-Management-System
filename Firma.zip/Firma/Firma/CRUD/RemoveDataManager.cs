﻿using System;
using System.Data.OleDb;
using System.Windows.Forms;


namespace Firma
{
    class RemoveDataManager : DataManager, CRUD.IRemovable
    {
        public RemoveDataManager() : base()
        {

        }

        private void ExecuteDeleteQuery(string query, string objectName)
        {
            bool flagCloseConnection;
            try
            {
                flagCloseConnection = OpenConnectionWhenClosed();
                OleDbCommand cmd = new OleDbCommand(query, Conn);
                cmd.ExecuteNonQuery();
                CloseConnection(flagCloseConnection);
            }
            catch (Exception e)
            {
                ShowErrorAndCloseConnection(e.Message, objectName);
                Conn.Close();
            }
        }

        private void RemoveAddress(int addressID)
        {
            string querySQL = $"DELETE * FROM Address WHERE ID = {addressID}";
            ExecuteDeleteQuery(querySQL, "Address");
        }

        private void RemoveEmployeeData(int empDataID)
        {
            string querySQL = $"DELETE * FROM EmployeeData WHERE ID = {empDataID}";
            ExecuteDeleteQuery(querySQL, "Employee Data");
        }

        public void RemoveEmployee(Employee employee)
        {            
            RemoveAddress(employee);
            RemoveEmployeeData(employee);

            string querySQL = $"DELETE * FROM Employee WHERE ID = {employee.EmployeeID}";
            ExecuteDeleteQuery(querySQL, "Employee");
        }

        private void ShowErrorAndCloseConnection(string errorMessage, string objectName)
        {
            MessageBox.Show($"Error while removing {objectName}. \n" +
                            $"{errorMessage}");
            Conn.Close();
        }

        public void RemoveAddress(Employee employee)
        {
            int addressId = GetAddressIdByEmployeeId(employee.EmployeeID);
            RemoveAddress(addressId);
        }

        public void RemoveEmployeeData(Employee employee)
        {
            int employmentDataId = GetEmpDataIdByEmployeeId(employee.EmployeeID);
            RemoveEmployeeData(employmentDataId);
        }

       
    }
}
