﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Linq;

namespace Firma
{
    //todo - przerobic metodki AddDirector i Assistant tak, zeby tylko updatowaly jedno pole zamiast
    //aktualizowac cala baze
    class AddDataManager : DataManager, CRUD.IInsertable
    {
        public AddDataManager() : base()
        {

        }

        public new void AddNewDepartment(string departmentName)
        {
            try
            {
                base.AddNewDepartment(departmentName);
            }
            catch (Exception e)
            {

                ShowErrorAndCloseConnection(departmentName, e.Message);
            }
        }

        public void AddNewDirector(Director director)
        {
            int empID = AddNewEmployee(director);
            string querySQL = "UPDATE Employee SET RoomNumber = @RoomNumber WHERE ID=@ID;";

            try
            {
                Conn.Open();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@RoomNumber", director.RoomNumber);
                cmd.Parameters.AddWithValue("@ID", empID);
                cmd.ExecuteNonQuery();
                Conn.Close();
            }
            catch (Exception e)
            {
                ShowErrorAndCloseConnection(director.EmployeeData.EmployeePosition, e.Message);
            }
        }

        public void AddNewAsistant(Assistant assistant)
        {
            int empID = AddNewEmployee(assistant);
            string querySQL = "UPDATE Employee SET PhoneNumber = @PhoneNumber WHERE ID=@ID;";

            try
            {
                Conn.Open();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@PhoneNumber", assistant.PhoneNumber);
                cmd.Parameters.AddWithValue("@ID", empID);
                cmd.ExecuteNonQuery();
                Conn.Close();
            }
            catch (Exception e)
            {
                ShowErrorAndCloseConnection(assistant.EmployeeData.EmployeePosition, e.Message);
            }
        }

        private void ShowErrorAndCloseConnection(string position, string errorMessage)
        {
            MessageBox.Show($"Cannot add {position}!!! {Environment.NewLine}" +
                                $"{errorMessage}");
            Conn.Close();
        }
        public int AddNewEmployee(Employee employee)
        {
            int addressID = AddNewAddress(employee.Address);
            int empDataID = AddNewEmployeeData(employee.EmployeeData);
            int empID = addEmployeeWithGeneratedIDs(employee, addressID, empDataID);
            employee.EmployeeID = empID;
            return empID;
        }

        private int addEmployeeWithGeneratedIDs(Employee employee, int addressID, int empDataID)
        {
            string querySQL = "INSERT INTO Employee (EmployeeName, Surname, BirthDate," +
                              "EmployeeDataID, AddressID)" +
                              " Values (@EmployeeName, @Surname, @BirthDate," +
                              "@EmployeeDataID, @AddressID)";
            try
            {
                Conn.Open();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@EmployeeName", employee.EmployeeName);
                cmd.Parameters.AddWithValue("@Surname", employee.Surname);
                cmd.Parameters.AddWithValue("@BirthDate", employee.BirthDate);
                cmd.Parameters.AddWithValue("@EmployeeDataID", empDataID);
                cmd.Parameters.AddWithValue("@AddressID", addressID);
                cmd.ExecuteNonQuery();
                Conn.Close();

                List<string> maxID = RecordsetToList("SELECT MAX(ID) FROM Employee");
                return Convert.ToInt32(maxID.First());

            }
            catch (Exception e)
            {
                ShowErrorAndCloseConnection(employee.EmployeeData.EmployeePosition, e.Message);
                return -1;
            }
        }

            public int AddNewEmployeeData(EmployeeData data)
        {
            string querySQL = "INSERT INTO EmployeeData (DepartmentID, EmploymentDate, Salary," +
                              " EmployeePosition)" +
                              " Values (@DepartmentID, @EmploymentDate, @Salary, @EmployeePosition)";
            int depID = GetDepartmentIDByName(data.Department);

            try
            {
                Conn.Open();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@DepartmentID", depID);
                cmd.Parameters.AddWithValue("@EmploymentDate", data.EmploymentDate);
                cmd.Parameters.AddWithValue("@Salary", data.Salary);
                cmd.Parameters.AddWithValue("@Salary", data.EmployeePosition);
                cmd.ExecuteNonQuery();
                Conn.Close();
                List<string> maxID = RecordsetToList("SELECT MAX(ID) FROM EmployeeData");
                return Convert.ToInt32(maxID.First());
            }
            catch (Exception e)
            {
                ShowErrorAndCloseConnection("employee data", e.Message);
                return -1;
            }

        }
        private int GetDepartmentIDByName(string department)
        {
            string querySQL = $"SELECT ID FROM Department WHERE Department='{department}'";
            List<string> depID = RecordsetToList(querySQL);
            return Convert.ToInt32(depID.First());

        }
        public int AddNewAddress(Address address)
        {
            string querySQL = "INSERT INTO Address (City, Street, ZipCode)" +
                              " Values (@City, @Street, @ZipCode)";
            try
            {
                Conn.Open();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@City", address.City);
                cmd.Parameters.AddWithValue("@Street", address.Street);
                cmd.Parameters.AddWithValue("@ZipCode", address.ZipCode);
                cmd.ExecuteNonQuery();
                Conn.Close();
                List<string> maxID = RecordsetToList("SELECT MAX(ID) FROM Address");
                return Convert.ToInt32(maxID.First());
            }
            catch (Exception e)
            {
                ShowErrorAndCloseConnection("address", e.Message);
                return -1;
            }
        }
    }


}
