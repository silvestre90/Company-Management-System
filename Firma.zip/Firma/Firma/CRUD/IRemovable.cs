﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma.CRUD
{
    interface IRemovable
    {
        void RemoveAddress(Employee employee);
        void RemoveEmployeeData(Employee employee);
        void RemoveEmployee(Employee employee);
    }
}
