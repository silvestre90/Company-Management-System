﻿using System;
using System.Data.OleDb;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma.CRUD
{
    public class UpdateDataManager : DataManager, CRUD.IUpdatable
    {
        public void PromoteEmployee(Employee employee, string newPosition)
        {
            int empDataId = GetEmpDataIdByEmployeeId(employee.EmployeeID);

            string query = $"UPDATE EmployeeData SET EmployeePosition = '{newPosition}'" +
                           $" WHERE ID = {empDataId}";
            ExecuteUpdateQuery(query);

        }

        

        public void UpdateAddress(Employee employee, Address newAddress)
        {
            int addressId = GetAddressIdByEmployeeId(employee.EmployeeID);
            string query = $"UPDATE Address SET City = '{newAddress.City}', Street = '{newAddress.Street}'," +
                            $" ZipCode = '{newAddress.ZipCode}'" +
                            $" WHERE ID = {addressId}";
            ExecuteUpdateQuery(query);
        }

        public void UpdateEmployee(Employee employee, Dictionary<String, String> newData)
        {
            string query = $"UPDATE Employee SET EmployeeName = '{newData["Name"]}'," +
                           $" Surname = '{newData["Surname"]}'" +
                           $" WHERE ID = {employee.EmployeeID}";
            ExecuteUpdateQuery(query);
        }

        public void UpdateEmployeeData(Employee employee, EmployeeData newEmploymentData)
        {
            int empDataId = GetEmpDataIdByEmployeeId(employee.EmployeeID);
            string query = $"UPDATE EmployeeData SET Salary = {newEmploymentData.Salary}," +
                           $" EmployeePosition = '{newEmploymentData.EmployeePosition}'" +
                           $" WHERE ID = {empDataId}";
            ExecuteUpdateQuery(query);
        }

        private void ExecuteUpdateQuery(string query)
        {
            bool flagCloseConnection;
            try
            {
                flagCloseConnection = OpenConnectionWhenClosed();
                OleDbCommand cmd = new OleDbCommand(query, Conn);
                cmd.ExecuteNonQuery();
                CloseConnection(flagCloseConnection);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                Conn.Close();
            }
        }
    }
}
