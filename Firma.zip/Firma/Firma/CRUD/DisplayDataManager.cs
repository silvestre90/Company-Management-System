﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Firma.CRUD;

namespace Firma
{
    class DisplayDataManager : DataManager
    {
        public DisplayDataManager() : base()
        {


        }


        internal Employee GetEmployeeBySurnameAndDepartment(string department, string surname)
        {
            List<Employee> employees = GetAllEmployees();
            Employee employee = employees.Find(Employee => Employee.EmployeeData.Department == department
                                                    && Employee.Surname == surname);
            
            return employee;
                                                        
        }

        
    }
}
