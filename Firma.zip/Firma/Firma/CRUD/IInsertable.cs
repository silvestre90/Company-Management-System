﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma.CRUD
{
    interface IInsertable
    {
        int AddNewEmployee(Employee employee);
        int AddNewAddress(Address address);
        int AddNewEmployeeData(EmployeeData data);
        void AddNewAsistant(Assistant assistant);
        void AddNewDirector(Director director);
    }
}
