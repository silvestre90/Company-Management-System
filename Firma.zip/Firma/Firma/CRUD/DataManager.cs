﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Linq;



namespace Firma
{
    //todo - zweryfikuj czy metoda display dziala poprawnie - trzeba dodac Position do tabeli EmployeeData
    // plus przetestowac funkcjonalnosc Delete Employee
    public abstract class DataManager: IDepartmentData, CRUD.IGetable

    {

        public OleDbConnection Conn;
        private const string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;" +
                @"Data source= C:\C#\repos\Firma\Firma\appdata\Firma.accdb";
        private const string openedConnection = "Opened";
        private const string closedConnection = "Closed";

        protected DataManager()
        {
            Conn = createConnection();
        }

        public List<Employee> GetAllEmployees()
        {
            return GetAllEmployeeDataToList();
        }

        public List<String> GetSurnamesByDepartment(string department)
        {
            List<Employee> employeesByDepartment = GetEmployeesByDepartment(department);
            List<string> surnames = (from e in employeesByDepartment select e.Surname).Distinct().ToList();
            return surnames;
        }


        public List<String> GetAllSurnames()
        {
            List<String> surnames = RecordsetToList("SELECT DISTINCT Surname FROM Employee");
            return surnames;
        }

        public List<Employee> GetEmployeesByDepartment(string department)
        {
            List<Employee> employees = GetAllEmployees();

            List<Employee> employeesByDepartment = employees.FindAll(Employee =>
                                                     Employee.EmployeeData.Department == department);

            return employeesByDepartment;
        }

        public Employee GetEmployeeById(int id)
        {
            List<Employee> employees = GetAllEmployees();
            Employee employee = (from e in employees where e.EmployeeID == id select e).First();
            return employee;
        }



        public List<Employee> GetEmployeesBySurname(string surname)
        {
            List<Employee> employees = GetAllEmployees();

            List<Employee> employeesBySurname = employees.FindAll(BasicEmployee =>
                                                     BasicEmployee.Surname == surname);

            return employeesBySurname;
        }


        public List<Address> GetAllAddresses()
        {
            throw new NotImplementedException();
        }

        public Address GetAddressById(int id)
        {
            string querySQL = "SELECT * FROM Address WHERE ID=@ID";
            List<Address> recordsList;
            bool flagCloseConnection;
            try
            {
                flagCloseConnection = OpenConnectionWhenClosed();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@ID", id);
                OleDbDataReader reader = cmd.ExecuteReader();
                recordsList = new List<Address>();

                while (reader.Read())
                {
                    recordsList.Add(new Address(reader[1].ToString(), reader[2].ToString(),
                                    reader[3].ToString()));
                }
                CloseConnection(flagCloseConnection);

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                Conn.Close();
                return null;
            }

            Address address = (from e in recordsList select e).First();
            return address;
        }

        public List<EmployeeData> GetAllEmployeesData()
        {
            throw new NotImplementedException();
        }

        private string GetDepartmentById(int id)
        {
            List<String> depsList = RecordsetToList($"SELECT Department FROM Department WHERE ID={id}");
            return depsList.First();

        }

        public EmployeeData GetEmployeeDataById(int id)
        {
            string querySQL = "SELECT * FROM EmployeeData WHERE ID=@ID";
            List<EmployeeData> recordsList;
            bool flagCloseConnection;
            try
            {
                flagCloseConnection = OpenConnectionWhenClosed();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@ID", id);
                OleDbDataReader reader = cmd.ExecuteReader();
                recordsList = new List<EmployeeData>();

                while (reader.Read())
                {
                    recordsList.Add(new EmployeeData(GetDepartmentById(Convert.ToInt32(reader[1].ToString())),
                                    Convert.ToDateTime(reader[2].ToString()),Convert.ToDouble(reader[3].ToString()),
                                    reader[4].ToString()));
                }
                CloseConnection(flagCloseConnection);

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                Conn.Close();
                return null;
            }

            EmployeeData empData = (from e in recordsList select e).First();
            return empData;
        }

        public bool OpenConnectionWhenClosed()
        {
            if(Conn.State.ToString() == closedConnection)
            {
                Conn.Open();
                return true;
            }
            return false;
        }

        public List<String> RecordsetToList(string qry)
        {
            bool flagCloseConnection;
            try
            {
                flagCloseConnection = OpenConnectionWhenClosed();
                OleDbCommand cmd = new OleDbCommand(qry, Conn);
                OleDbDataReader reader = cmd.ExecuteReader();

                List<string> recordsList = new List<string>();
                while (reader.Read())
                {
                    recordsList.Add(reader[0].ToString());
                }
                CloseConnection(flagCloseConnection);
                return recordsList;
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
                return null;
            }
            
        }

        public void CloseConnection(bool flagCloseConnection)
        {
            if (flagCloseConnection)
            {
                Conn.Close();
            }
        }

        public List<string> GetDepartments()
        {
            List<String> depsList = RecordsetToList("SELECT Department FROM Department");
            return depsList;
        }

        public List<int> GetSearchedEmployeeID(string department, string surname)
        {
            List<Employee> employees = GetAllEmployeeDataToList();

            List<int> employeeIDs = (from e in employees
                                     where e.Surname == surname && e.EmployeeData.Department == department
                                     select e.EmployeeID).ToList();
            return employeeIDs;
        }

        public List<Employee> GetAllEmployeeDataToList()
        {   

            string qry = "SELECT * FROM Employee";
            bool flagCloseConnection;
            try
            {
                flagCloseConnection = OpenConnectionWhenClosed();
                OleDbCommand cmd = new OleDbCommand(qry, Conn);
                OleDbDataReader reader = cmd.ExecuteReader();

                List<Employee> recordsList = new List<Employee>();
                while (reader.Read())
                {
                    recordsList.Add(new Employee(Convert.ToInt32(reader[0].ToString()), reader[1].ToString(),
                                    reader[2].ToString(), Convert.ToDateTime(reader[3].ToString()),
                                    GetEmployeeDataById(Convert.ToInt32(reader[6].ToString())),
                                    GetAddressById(Convert.ToInt32(reader[7].ToString()))));
                }
                CloseConnection(flagCloseConnection);
                return recordsList;
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
                Conn.Close();
                return null;
            }
            
        }

        private int GetObjectIdFromMainTable(string objectName, int employeeID)
        {
            int id = Convert.ToInt32(RecordsetToList(
                     $"SELECT {objectName} FROM Employee WHERE ID={employeeID}")
                     .First());
            return id;
        }

        public int GetEmpDataIdByEmployeeId(int employeeID)
        {
            return GetObjectIdFromMainTable("EmployeeDataID", employeeID);
        }
        public int GetAddressIdByEmployeeId(int employeeID)
        {
            return GetObjectIdFromMainTable("AddressID",employeeID);
        }

        public OleDbConnection createConnection()
        {
            OleDbConnection conn = new OleDbConnection();

            conn.ConnectionString = connectionString;

            try
            {
                conn.Open();
                conn.Close();
                return conn;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                conn.Close();
                return null;
            }
        }


         public void AddNewDepartment(string departmentName)
        {
            string querySQL = "INSERT INTO Department (Department)" +
                             " Values (@Department)";
            bool flagCloseConnection;
            try
            {
                flagCloseConnection = OpenConnectionWhenClosed();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@Department", departmentName);
                cmd.ExecuteNonQuery();
                CloseConnection(flagCloseConnection);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                Conn.Close();
            }
            
        }

        public List<Employee> GetDepartmentHierarchy(string department)
        {
            List<Employee> employeesByDepartment = GetEmployeesByDepartment(department);
            return(ListSortedByHierarchy(employeesByDepartment));
                                         
        }

        private List<Employee> ListSortedByHierarchy(List<Employee> employeesByDepartment)
        {
            int numberOfPositions = Enum.GetNames(typeof(Position)).Length;
            List<Employee> sortedList = new List<Employee>();
            for (int i = numberOfPositions; i > 0; i--)
            {
                sortedList.AddRange(GetEmployeeByPosition(employeesByDepartment, i));
            }
            return sortedList;
        }

        private List<Employee> GetEmployeeByPosition(List<Employee> employeesByDepartment, int positionIndex)
        {
            string positionName = ((Position)positionIndex).ToString();
            List<Employee> empList = (from e in employeesByDepartment
                                      where e.EmployeeData.EmployeePosition == positionName
                                      select e).ToList();
            return empList;

        }
    }
}
