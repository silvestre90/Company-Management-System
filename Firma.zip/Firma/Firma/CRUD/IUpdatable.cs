﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma.CRUD
{
    interface IUpdatable
    {
        void UpdateEmployee(Employee employee, Dictionary<String,String> newData);
        void UpdateAddress(Employee employee, Address address);
        void UpdateEmployeeData(Employee employee, EmployeeData newEmploymentData);
        void PromoteEmployee(Employee empToBePromoted, string newPosition);
    }
}
