﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firma.CRUD
{
    interface IGetable
    {
        List<Employee> GetAllEmployees();
        Employee GetEmployeeById(int id);
        List<Employee> GetEmployeesBySurname(string surname);
        List<Employee> GetEmployeesByDepartment(string department);

        List<String> GetAllSurnames();
        List<String> GetSurnamesByDepartment(string department);

        List<Address> GetAllAddresses();
        Address GetAddressById(int id);

        List<EmployeeData> GetAllEmployeesData();
        EmployeeData GetEmployeeDataById(int id);
        List<Employee> GetDepartmentHierarchy(string department);
    }
}
