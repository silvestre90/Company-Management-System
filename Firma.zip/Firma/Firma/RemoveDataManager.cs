﻿using System;
using System.Data.OleDb;
using System.Windows.Forms;


namespace Firma
{
    class RemoveDataManager : DataManager
    {
        public RemoveDataManager() : base()
        {

        }


        private void removeAddress(int addressID)
        {
            string querySQL = "DELETE * FROM Address WHERE ID = @ID";

            try
            {
                Conn.Open();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@ID", addressID);
                cmd.ExecuteNonQuery();
                Conn.Close();
            }
            catch (Exception e)
            {
                showErrorAndCloseConnection(e.Message, "Address");
            }
        }

        private void removeEmployeeData(int empDataID)
        {
            string querySQL = "DELETE * FROM EmployeeData WHERE ID = @ID";

            try
            {
                Conn.Open();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@ID", empDataID);
                cmd.ExecuteNonQuery();
                Conn.Close();
            }
            catch (Exception e)
            {
                showErrorAndCloseConnection(e.Message, "Employment Data");
            }
        }


        public void removeEmployee(BasicEmployee employee)
        {
            int empID = employee.EmployeeID;
            removeAddress(employee.AddressID);
            removeEmployeeData(employee.EmployeeDataID);

            if(employee.EmployeePosition == Position.director.ToString())
            {
                removeDirector(empID);
            }else if (employee.EmployeePosition == Position.asistant.ToString())
            {
                removeAssistant(empID);
            }

            string querySQL = "DELETE * FROM Employee WHERE ID = @ID";

            try
            {
                Conn.Open();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@ID", empID);
                cmd.ExecuteNonQuery();
                Conn.Close();
            }
            catch (Exception e)
            {
                showErrorAndCloseConnection(e.Message, "Employee");
            }

        }
        private void removeDirector(int employeeID)
        {
            string querySQL = "DELETE * FROM Director WHERE EmployeeID = @ID";

            try
            {
                Conn.Open();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@ID", employeeID);
                cmd.ExecuteNonQuery();
                Conn.Close();
            }
            catch (Exception e)
            {
                showErrorAndCloseConnection(e.Message, "Director");
            }
        }

        private void removeAssistant(int employeeID)
        {
            string querySQL = "DELETE * FROM Assistant WHERE EmployeeID = @ID";

            try
            {
                Conn.Open();
                OleDbCommand cmd = new OleDbCommand(querySQL, Conn);
                cmd.Parameters.AddWithValue("@ID", employeeID);
                cmd.ExecuteNonQuery();
                Conn.Close();
            }
            catch (Exception e)
            {
                showErrorAndCloseConnection(e.Message, "Assistant");
            }
        }

        private void showErrorAndCloseConnection(string errorMessage, string objectName)
        {
            MessageBox.Show($"Error while removing {objectName}. \n" +
                            $"{errorMessage}");
            Conn.Close();
        }
    }
}
